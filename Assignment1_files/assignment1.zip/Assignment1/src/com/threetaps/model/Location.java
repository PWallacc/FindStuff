package com.threetaps.model;

public class Location {
  
}