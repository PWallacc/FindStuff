package com.threetaps.util;

public class Constants {
	public static String DEFAULT_API_URL = "http://3taps.net";
	public static int DEFAULT_API_PORT = 80;
	public static String DATE_FORMAT = "yyyy/MM/dd HH:mm:ss z";
}
