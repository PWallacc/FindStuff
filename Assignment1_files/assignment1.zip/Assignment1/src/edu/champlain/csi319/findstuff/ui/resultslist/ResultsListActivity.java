package edu.champlain.csi319.findstuff.ui.resultslist;

import edu.champlain.csi319.findstuff.R;

import android.app.Activity;
import android.os.Bundle;


public class ResultsListActivity extends Activity
{
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.resultslist_activity);
    }
}
