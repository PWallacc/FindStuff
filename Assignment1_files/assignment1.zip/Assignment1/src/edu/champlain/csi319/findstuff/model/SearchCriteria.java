package edu.champlain.csi319.findstuff.model;


public class SearchCriteria
{
 
    /**
     * Default Constructor - does nothing
     */
    public SearchCriteria() { }
    
    
}
