package com.threetaps.dto.search;

import java.util.Map;

public interface QueryRequest {
	
	public Map<String, String> getQueryParams();

}
