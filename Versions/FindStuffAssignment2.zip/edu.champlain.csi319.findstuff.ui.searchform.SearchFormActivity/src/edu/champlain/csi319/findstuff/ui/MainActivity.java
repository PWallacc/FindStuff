package edu.champlain.csi319.findstuff.ui;

import edu.champlain.csi319.findstuff.R;
import android.os.Bundle;
import android.app.Activity;

public class MainActivity extends Activity 
{

    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);
    }
    
}
