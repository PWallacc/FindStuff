package edu.champlain.csi319.findstuff.ui.resultslist;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import edu.champlain.csi319.findstuff.content.SearchTask;
import edu.champlain.csi319.findstuff.model.*;
import android.app.ListFragment;
import android.os.Bundle;
import android.widget.Toast;
import android.app.LoaderManager;
import android.content.Loader;



public class ResultsListFragment extends ListFragment implements LoaderManager.LoaderCallbacks<List<SearchResult>>
{   
    private List<SearchResult> resultsList;
    private SearchTask searchTask;
    private ResultListAdapter myAdapter;
    private int currentPage = 0;

    
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {        
    	super.onCreate(savedInstanceState); 
    }
    
    @Override
    public void onResume()
    {
    	super.onResume();
    	currentPage++;
   	
    	LoaderManager loaderManager = getLoaderManager();
    	loaderManager.initLoader(0, null, this);
    	 
    }

	@Override
	public Loader<List<SearchResult>> onCreateLoader(int id, Bundle bundle)
	{
		// TODO Auto-generated method stub        
    	SearchCriteria searchCriteria = (SearchCriteria)getActivity().getIntent().getParcelableExtra("SearchCriteria");        
        
 		return new SearchTask(getActivity().getApplicationContext(), searchCriteria, 20, currentPage);
	}

	@Override
	public void onLoadFinished(Loader<List<SearchResult>> loader, List<SearchResult> resultsList) 
	{
		myAdapter = new ResultListAdapter(this.getActivity(), resultsList);
		//myAdapter.addAll(resultsList);
		setListAdapter(myAdapter);
	}

	@Override
	public void onLoaderReset(Loader<List<SearchResult>> arg0) {
		// TODO Auto-generated method stub

		
	}
}
