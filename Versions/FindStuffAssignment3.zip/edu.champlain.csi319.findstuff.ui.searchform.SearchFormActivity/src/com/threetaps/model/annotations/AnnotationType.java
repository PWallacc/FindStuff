package com.threetaps.model.annotations;

public enum AnnotationType {
	SELECT, STRING, NUMBER
}
