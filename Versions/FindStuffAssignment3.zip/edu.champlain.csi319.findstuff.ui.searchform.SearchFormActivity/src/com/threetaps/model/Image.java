package com.threetaps.model;

public class Image
{
    private String full = new String();
    
    public Image() {}

    public String getFull()
    {
        return full;
    }

    public void setFull(String full)
    {
        this.full = full;
    }
    
    
    
}
